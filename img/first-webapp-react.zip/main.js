var React = require('react');
var App = require('./components/App');

React.render(
  <App />,
  document.getElementById('main')
);
